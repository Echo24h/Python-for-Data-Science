from setuptools import setup, find_packages


setup(
    name='ft_package',
    version='0.0.1',
    author='gborne',
    author_email='gborne@student.42.fr',
    description='A sample test package',
    url='https://github.com/gborne/ft_package',
    packages=find_packages(),
)
