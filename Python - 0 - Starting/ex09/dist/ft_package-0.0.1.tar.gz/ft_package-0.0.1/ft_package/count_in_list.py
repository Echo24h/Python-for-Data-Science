def count_in_list(lst, value):
    return lst.count(value)
